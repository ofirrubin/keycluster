import logging
import os
import re
import urllib.parse
import uuid
from typing import List, Optional, Set
from fastapi import APIRouter, HTTPException, Depends, Query, Request
from pydantic import BaseModel, field_validator
import httpx
from urllib.parse import quote

from app.auth import (
    require_admin,
    introspect_token,
    audit_log,
    validate_realm_name,
    get_keycloak_admin_token,
    KEYCLOAK_SERVER_URL,
)
from app.rate_limit import limiter

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Role allowlist
# ---------------------------------------------------------------------------
_raw_allowed_roles: str = os.getenv("ALLOWED_GRANTABLE_ROLES", "")
ALLOWED_GRANTABLE_ROLES: Optional[Set[str]] = (
    {r.strip() for r in _raw_allowed_roles.split(",") if r.strip()}
    if _raw_allowed_roles
    else None
)

router = APIRouter(
    prefix="/v1/realms/{realm}/service-accounts",
    tags=["service-accounts"],
)

_CLIENT_ID_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,253}[a-zA-Z0-9]$")


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class ServiceAccountCreate(BaseModel):
    client_id: str
    description: str = ""
    roles: List[str] = []

    @field_validator("client_id")
    @classmethod
    def validate_client_id(cls, v: str) -> str:
        if not _CLIENT_ID_PATTERN.match(v):
            raise ValueError(
                "client_id must be 2-255 alphanumeric characters, dots, hyphens, or underscores"
            )
        return v

    @field_validator("description")
    @classmethod
    def validate_description(cls, v: str) -> str:
        if len(v) > 500:
            raise ValueError("Description must be under 500 characters")
        return v

    @field_validator("roles")
    @classmethod
    def validate_roles(cls, v: List[str]) -> List[str]:
        if len(v) > 100:
            raise ValueError("A service account must not have more than 100 roles")
        for role in v:
            if not re.match(r"^[a-zA-Z0-9_-]{1,100}$", role):
                raise ValueError("Invalid role name format")
        return v


class ServiceAccountResponse(BaseModel):
    id: str
    client_id: str
    description: str
    enabled: bool


class ServiceAccountSecret(BaseModel):
    client_id: str
    secret: str


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------
async def _admin_headers() -> dict:
    token = await get_keycloak_admin_token()
    if not token:
        raise HTTPException(
            status_code=502, detail="Failed to obtain Keycloak admin token"
        )
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


async def _resolve_client_internal_id(
    http: httpx.AsyncClient,
    realm: str,
    client_id: str,
    headers: dict,
) -> str:
    """Resolve a Keycloak clientId to its internal UUID."""
    encoded_realm = urllib.parse.quote(realm, safe="")
    resp = await http.get(
        f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/clients",
        params={"clientId": client_id},
        headers=headers,
        timeout=10.0,
    )
    try:
        resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        logger.error(
            "Failed to resolve client: exc_type=%s status=%s",
            type(exc).__name__, exc.response.status_code,
        )
        raise HTTPException(status_code=502, detail="Keycloak operation failed")
    matches = resp.json()

    for m in matches:
        if m["clientId"] == client_id:
            return m["id"]

    raise HTTPException(status_code=404, detail="Client not found")


async def _assign_service_account_roles(
    http: httpx.AsyncClient,
    realm: str,
    internal_client_id: str,
    role_names: List[str],
    headers: dict,
) -> None:
    """Assign realm roles to the service account user of a client."""
    encoded_realm = urllib.parse.quote(realm, safe="")
    sa_resp = await http.get(
        f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/clients/{internal_client_id}/service-account-user",
        headers=headers,
        timeout=10.0,
    )
    try:
        sa_resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        logger.error(
            "Failed to get service account user: exc_type=%s status=%s",
            type(exc).__name__, exc.response.status_code,
        )
        raise HTTPException(status_code=502, detail="Keycloak operation failed")
    sa_user_id = sa_resp.json()["id"]

    role_payloads = []
    for rn in role_names:
        encoded_role = urllib.parse.quote(rn, safe="")
        role_resp = await http.get(
            f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/roles/{encoded_role}",
            headers=headers,
            timeout=10.0,
        )
        if role_resp.status_code == 404:
            logger.warning("Role not found in realm, skipping: exc_type=NotFound")
            continue
        try:
            role_resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.error(
                "Failed to fetch role: exc_type=%s status=%s",
                type(exc).__name__, exc.response.status_code,
            )
            raise HTTPException(status_code=502, detail="Keycloak operation failed")
        role_payloads.append(role_resp.json())

    if role_payloads:
        assign_resp = await http.post(
            f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/users/{sa_user_id}/role-mappings/realm",
            json=role_payloads,
            headers=headers,
            timeout=10.0,
        )
        try:
            assign_resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.error(
                "Failed to assign roles: exc_type=%s status=%s",
                type(exc).__name__, exc.response.status_code,
            )
            raise HTTPException(status_code=502, detail="Keycloak operation failed")


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
_MAX_PAGE_SIZE: int = 100


@router.get("", response_model=List[ServiceAccountResponse])
@limiter.limit("60/minute")
async def list_service_accounts(
    request: Request,
    realm: str,
    first: int = Query(0, ge=0, description="Pagination offset"),
    max_results: int = Query(
        _MAX_PAGE_SIZE, ge=1, le=_MAX_PAGE_SIZE, alias="max",
        description="Maximum number of results to return",
    ),
    claims: dict = Depends(require_admin),
):
    """List clients with service accounts enabled in the realm. Admin only.

    Supports pagination via ``first`` (offset) and ``max`` (page size, capped
    at 100) query parameters.
    """
    validate_realm_name(realm)

    headers = await _admin_headers()
    encoded_realm = urllib.parse.quote(realm, safe="")

    async with httpx.AsyncClient() as http:
        resp = await http.get(
            f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/clients",
            params={"first": first, "max": max_results},
            headers=headers,
            timeout=10.0,
        )
        if resp.status_code == 404:
            raise HTTPException(
                status_code=404, detail="Realm not found"
            )
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.error(
                "Failed to list clients: exc_type=%s status=%s",
                type(exc).__name__, exc.response.status_code,
            )
            raise HTTPException(status_code=502, detail="Keycloak operation failed")
        clients = resp.json()

    result: List[ServiceAccountResponse] = []
    for c in clients:
        if not c.get("serviceAccountsEnabled", False):
            continue
        result.append(
            ServiceAccountResponse(
                id=c["id"],
                client_id=c["clientId"],
                description=c.get("description", ""),
                enabled=c.get("enabled", True),
            )
        )

    return result


@router.post("", response_model=ServiceAccountSecret, status_code=201)
@limiter.limit("15/minute")
async def create_service_account(
    request: Request,
    realm: str,
    body: ServiceAccountCreate,
    claims: dict = Depends(require_admin),
):
    """Create a new service account client in the realm. Admin only."""
    validate_realm_name(realm)

    # Enforce role allowlist when configured
    if ALLOWED_GRANTABLE_ROLES is not None and body.roles:
        disallowed: List[str] = [
            r for r in body.roles if r not in ALLOWED_GRANTABLE_ROLES
        ]
        if disallowed:
            raise HTTPException(
                status_code=403,
                detail="Some requested roles are not permitted",
            )

    headers = await _admin_headers()
    encoded_realm = urllib.parse.quote(realm, safe="")

    client_payload = {
        "clientId": body.client_id,
        "description": body.description,
        "enabled": True,
        "protocol": "openid-connect",
        "publicClient": False,
        "serviceAccountsEnabled": True,
        "standardFlowEnabled": False,
        "directAccessGrantsEnabled": False,
        "clientAuthenticatorType": "client-secret",
    }

    async with httpx.AsyncClient() as http:
        # Create client
        resp = await http.post(
            f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/clients",
            json=client_payload,
            headers=headers,
            timeout=10.0,
        )
        if resp.status_code == 409:
            raise HTTPException(
                status_code=409,
                detail="Client already exists",
            )
        if resp.status_code == 404:
            raise HTTPException(
                status_code=404, detail="Realm not found"
            )
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.error(
                "Failed to create client: exc_type=%s status=%s",
                type(exc).__name__, exc.response.status_code,
            )
            raise HTTPException(status_code=502, detail="Keycloak operation failed")

        # Get internal ID from Location header and validate UUID format
        internal_id: Optional[str] = None
        location = resp.headers.get("Location", "")
        if location:
            candidate = location.rsplit("/", 1)[-1]
            try:
                uuid.UUID(candidate)
                internal_id = candidate
            except ValueError:
                logger.warning(
                    "Location header contained invalid UUID: length=%d",
                    len(candidate),
                )

        if not internal_id:
            internal_id = await _resolve_client_internal_id(
                http, realm, body.client_id, headers
            )

        # Fetch the generated client secret
        secret_resp = await http.get(
            f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/clients/{internal_id}/client-secret",
            headers=headers,
            timeout=10.0,
        )
        try:
            secret_resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.error(
                "Failed to fetch client secret: exc_type=%s status=%s",
                type(exc).__name__, exc.response.status_code,
            )
            raise HTTPException(status_code=502, detail="Keycloak operation failed")
        secret = secret_resp.json().get("value", "")

        # Assign roles if requested
        if body.roles:
            await _assign_service_account_roles(
                http, realm, internal_id, body.roles, headers
            )

    audit_log(
        "service_account_create", claims, realm=realm,
        details=f"client_id={body.client_id}",
    )

    return ServiceAccountSecret(client_id=body.client_id, secret=secret)


@router.delete("/{client_id}")
@limiter.limit("15/minute")
async def delete_service_account(
    request: Request,
    realm: str,
    client_id: str,
    claims: dict = Depends(require_admin),
):
    """Delete a service account client from the realm. Admin only."""
    validate_realm_name(realm)

    # Defense-in-depth: introspect token for destructive operations to catch
    # revoked tokens within the JWKS cache TTL window.
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        token_active = await introspect_token(auth_header[7:])
        if not token_active:
            raise HTTPException(status_code=401, detail="Token has been revoked")

    if not _CLIENT_ID_PATTERN.match(client_id):
        raise HTTPException(status_code=400, detail="Invalid client_id format")

    headers = await _admin_headers()
    encoded_realm = urllib.parse.quote(realm, safe="")

    async with httpx.AsyncClient() as http:
        internal_id = await _resolve_client_internal_id(
            http, realm, client_id, headers
        )

        resp = await http.delete(
            f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/clients/{internal_id}",
            headers=headers,
            timeout=10.0,
        )
        if resp.status_code == 404:
            raise HTTPException(status_code=404, detail="Client not found")
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.error(
                "Failed to delete client: exc_type=%s status=%s",
                type(exc).__name__, exc.response.status_code,
            )
            raise HTTPException(status_code=502, detail="Keycloak operation failed")

    audit_log(
        "service_account_delete", claims, realm=realm,
        details=f"client_id={client_id}",
    )
    return {"status": "deleted", "realm": realm, "client_id": client_id}


@router.post("/{client_id}/rotate", response_model=ServiceAccountSecret)
@limiter.limit("10/minute")
async def rotate_client_secret(
    request: Request,
    realm: str,
    client_id: str,
    claims: dict = Depends(require_admin),
):
    """Rotate the client secret for a service account. Admin only."""
    validate_realm_name(realm)

    if not _CLIENT_ID_PATTERN.match(client_id):
        raise HTTPException(status_code=400, detail="Invalid client_id format")

    headers = await _admin_headers()
    encoded_realm = urllib.parse.quote(realm, safe="")

    async with httpx.AsyncClient() as http:
        internal_id = await _resolve_client_internal_id(
            http, realm, client_id, headers
        )

        # POST to regenerate the secret
        resp = await http.post(
            f"{KEYCLOAK_SERVER_URL}/admin/realms/{encoded_realm}/clients/{internal_id}/client-secret",
            headers=headers,
            timeout=10.0,
        )
        try:
            resp.raise_for_status()
        except httpx.HTTPStatusError as exc:
            logger.error(
                "Failed to rotate client secret: exc_type=%s status=%s",
                type(exc).__name__, exc.response.status_code,
            )
            raise HTTPException(status_code=502, detail="Keycloak operation failed")
        new_secret = resp.json().get("value", "")

    audit_log(
        "service_account_rotate_secret", claims, realm=realm,
        details=f"client_id={client_id}",
    )

    return ServiceAccountSecret(client_id=client_id, secret=new_secret)
